﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using CRUD.Data;
using CRUD.Models.Account;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
namespace CRUD.Controllers
{
    
    public class AccountController : Controller
    {
        private readonly ApplicationContext context;

        public AccountController(ApplicationContext context)
        {
            this.context = context;
        }
        [AllowAnonymous]
        public IActionResult HomePage()
        {
            return View();
        }
        [Authorize]
        public IActionResult UserIndex()
        {
            return View();
        }
        [Authorize]
        public IActionResult InstructorIndex()
        {
            return View();
        }
        [Authorize]
        public IActionResult AdminIndex()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(User1 model)
        {
            try
            {
                var nameQ = context.Users.SingleOrDefault(e => e.Username == model.Username);
                if (nameQ.Username != null && nameQ.Password != null)
                {
                    var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, model.Username) }, CookieAuthenticationDefaults.AuthenticationScheme);
                    var principal = new ClaimsPrincipal(identity);
                    HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                    HttpContext.Session.SetString("Username", model.Username);
                    if(nameQ.Role=="Admin")
                    {
                        return RedirectToAction("AdminIndex","Account");
                    }
                    else if (nameQ.Role == "Instructor")
                    {
                        return RedirectToAction("InstructorIndex", "Account");
                    }
                    return RedirectToAction("UserIndex", "Account");
                }
                else
                {
                    return View(model);
                }
            }
            catch(Exception e)
            {
                return BadRequest(e.Message);
            }

        }
        [Authorize]
        public IActionResult LogOut()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(User1 model)
        {

            if (ModelState.IsValid)
            {
                var nameQ = context.Users.SingleOrDefault(e => e.Username == model.Username);
                if (nameQ== null)
                {
                    var emp = new User1
                    {
                        Username = model.Username,
                        Email = model.Email,
                        Mobile = model.Mobile,
                        Password = model.Password,
                        Role = model.Role
                    };
                    context.Users.Add(emp);
                    context.SaveChanges();
                    TempData["success"] = "User Created!";
                    return RedirectToAction("Login");
                }
                else
                {
                    
                    return View(model);
                }
            }
                    
            else
            {
                return View(model);
            }
        }

    }
}