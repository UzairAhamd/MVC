﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.Models.Account
{
    public class User1
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Name can't be empty")]
        public string Username{ get; set; }
        [Required(ErrorMessage = "Email can't be empty")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Mobile# can't be empty")]
        public long? Mobile{ get; set; }
        [Required(ErrorMessage = "Password can't be empty")]
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
