﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.Models.DTO;

namespace WebApplication3.Repositories.Abstract
{
    interface IUserAuthenticationService
    {
        Task<Status> LoginAsync(LoginModel model);
        Task<Status> RegistrationAsync(RegisterationModel model);
        Task LogoutAsync();
    }
}
