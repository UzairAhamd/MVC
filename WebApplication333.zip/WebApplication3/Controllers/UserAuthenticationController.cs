﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication3.Repositories.Abstract;
using WebApplication3.Repositories.Implementation;
using WebApplication3.Models.DTO;
using Microsoft.AspNetCore.Authorization;

namespace WebApplication3.Controllers
{
    public class UserAuthentication : Controller
    {
        public  IUserAuthenticationService _authService;
        public UserAuthentication(IUserAuthenticationService service)
        {
            this._authService = service;
        }


        public IActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> Login(LoginModel model)
        {
            if (!ModelState.IsValid)
                return View(model);
            var result = await _authService.LoginAsync(model);
            if (result.StatusCode == 1)
            {
                return RedirectToAction("Display", "Dashboard");
            }
            else
            {
                TempData["msg"] = result.Message;
                return RedirectToAction(nameof(Login));
            }
        }

        public IActionResult Registration()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Registration(RegisterationModel model)
        {
            if (!ModelState.IsValid) { return View(model); }
            model.Role = "user";
            var result = await this._authService.RegistrationAsync(model);
            TempData["msg"] = result.Message;
            return RedirectToAction(nameof(Registration));
        }

        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await this._authService.LogoutAsync();
            return RedirectToAction(nameof(Login));
        }
        //[AllowAnonymous]
        //public async Task<IActionResult> Reg()
        //{
        //    var model = new RegisterationModel
        //    {
        //        Username = "admin1",
        //        Name = "John Adam",
        //        Email = "adam@gmail.com",
        //        //FirstName = "John",
        //        //LastName = "Doe",
        //        Password = "Admin@12345#"
        //    };
        //    model.Role = "admin";
        //    var result = await this._authService.RegistrationAsync(model);
        //    return Ok(result);
        //}

    }
}