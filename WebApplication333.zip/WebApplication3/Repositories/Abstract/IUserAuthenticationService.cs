﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.Models.DTO;

namespace WebApplication3.Repositories.Abstract
{
    public interface IUserAuthenticationService
    {
        public Task<Status> LoginAsync(LoginModel model);
        public Task<Status> RegistrationAsync(RegisterationModel model);
        public Task LogoutAsync();
    }
}
